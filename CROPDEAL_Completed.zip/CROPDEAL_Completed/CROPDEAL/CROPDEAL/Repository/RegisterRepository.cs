using CROPDEAL.Interfaces;
using CROPDEAL.Models;
using CROPDEAL.Data;
using Microsoft.AspNetCore.Mvc;
using CROPDEAL.Services;
using Microsoft.EntityFrameworkCore;
using CROPDEAL.Models.DTO;
using AutoMapper;

namespace CROPDEAL.Repository
{
    public class RegisterRepository : IAuth
    {
        private readonly CropDealDbContext c;
        private readonly IMapper mapper;
        private readonly PasswordService _passwordService;
        private readonly ILogger<RegisterRepository> log;

        public RegisterRepository(CropDealDbContext _r, ILogger<RegisterRepository> _log, IMapper _mapper, PasswordService passwordService)
        {
            c = _r;
            log = _log;
            mapper = _mapper;
            _passwordService = passwordService;
        }

        public async Task LogToDatabase(string level, string message, DateTime now)
        {
            var logEntry = new Log
            {
                LogLevel = level,
                Message = message,
                Timestamp = now
            };
            await c.Logs.AddAsync(logEntry);
            await c.SaveChangesAsync();
        }

        public async Task<User?> Login(LoginRequest request)
        {
            var user = await c.Users.FirstOrDefaultAsync(u => u.Email == request.Email);
            if (user == null)
            {
                return null;
            }

            if (!_passwordService.VerifyPassword(user.Password, request.Password))
            {
                return null;
            }

            return user;
        }

        public async Task<bool> Register(UserDTO u)
        {
            await LogToDatabase("Info", $"Registration attempt for User: {u.FullName}", DateTime.Now);

            try
            {
                if (await c.Users.AnyAsync(user => user.Email == u.Email))
                {
                    await LogToDatabase("Failed", $"User already exists for: {u.FullName} (Email: {u.Email})", DateTime.Now);
                    return false;
                }

                var hashedPassword = _passwordService.HashPassword(u.Password);
                var user = mapper.Map<User>(u);
                user.Password = hashedPassword;

                c.Users.Add(user);
                await c.SaveChangesAsync();

                await LogToDatabase("Success", $"Successful registration for User: {u.FullName} with Id: {user.UserId}", DateTime.Now);
                return true;
            }
            catch (Exception e)
            {
                await LogToDatabase("Failed", $"Registration failed for User: {u.FullName}. Exception: {e.Message}", DateTime.Now);
                return false;
            }
        }

        public async Task<IEnumerable<UserDTO>> GetAllUsers()
        {
            var users = await c.Users.ToListAsync();
            return mapper.Map<IEnumerable<UserDTO>>(users);
        }

        public async Task<UserDTO?> GetUserById(string userId)
        {
            var user = await c.Users.FindAsync(userId);
            return user == null ? null : mapper.Map<UserDTO>(user);
        }

        public async Task<bool> UpdateUser(string userId, UserDTO updatedUser)
        {
            var user = await c.Users.FindAsync(userId);
            if (user == null)
            {
                return false;
            }

            // Update profile details
            user.FullName = updatedUser.FullName ?? user.FullName;
            user.Email = updatedUser.Email ?? user.Email;

            // Hash password if provided
            if (!string.IsNullOrEmpty(updatedUser.Password))
            {
                user.Password = _passwordService.HashPassword(updatedUser.Password);
            }

            user.Status = updatedUser.Status ?? user.Status;

            c.Users.Update(user);
            await c.SaveChangesAsync();
            await LogToDatabase("Success", $"User updated successfully. Id: {userId}", DateTime.Now);
            return true;
        }

        public async Task<bool> DeleteUser(string userId)
        {
            var user = await c.Users.FindAsync(userId);
            if (user == null)
            {
                return false;
            }

            c.Users.Remove(user);
            await c.SaveChangesAsync();
            await LogToDatabase("Success", $"User deleted successfully. Id: {userId}", DateTime.Now);
            return true;
        }

        public async Task<User> GetUserByEmailAsync(string email)
        {
            return await c.Users.FirstOrDefaultAsync(u => u.Email == email);
        }
    }
}
