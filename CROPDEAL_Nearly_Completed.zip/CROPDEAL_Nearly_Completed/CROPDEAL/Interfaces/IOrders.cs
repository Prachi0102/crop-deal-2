using CROPDEAL.Models.DTO;

namespace CROPDEAL.Interfaces
{
    public interface IOrders
    {
        Task LogToDatabase(string level, string message, DateTime now);
        Task<IEnumerable<OrderDTO>> GetAllOrders();
        Task<OrderDTO> GetOrderById(string orderId);
        Task<IEnumerable<OrderDTO>> GetOrdersByUserId(string userId);

        Task<bool> AddOrder(OrderDTO order);
        Task<bool> UpdateOrder(string orderId, OrderDTO order);
        Task<bool> DeleteOrder(string orderId);

    }
}